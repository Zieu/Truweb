const scene = document.getElementById('scene');
const parallax = new Parallax(scene);